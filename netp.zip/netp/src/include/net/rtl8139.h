#ifndef RTL8139_H
#define RTL8139_H

#include "../../lib/types.h"

#define RTL8139_VENDOR_ID 0x10EC
#define RTL8139_DEVICE_ID 0x8139

#define RTL8139_REG_MAC0       0x00
#define RTL8139_REG_MAR0       0x08
#define RTL8139_REG_TXSTATUS0  0x10
#define RTL8139_REG_TXADDR0    0x20
#define RTL8139_REG_RXBUF      0x30
#define RTL8139_REG_CMD        0x37
#define RTL8139_REG_CAPR       0x38
#define RTL8139_REG_IMR        0x3C
#define RTL8139_REG_ISR        0x3E
#define RTL8139_REG_TCR        0x40
#define RTL8139_REG_RCR        0x44
#define RTL8139_REG_CONFIG1    0x52

#define RTL8139_CMD_RESET      0x10
#define RTL8139_CMD_RX_ENABLE  0x08
#define RTL8139_CMD_TX_ENABLE  0x04

#define RTL8139_INT_ROK        0x01
#define RTL8139_INT_RER        0x02
#define RTL8139_INT_TOK        0x04
#define RTL8139_INT_TER        0x08
#define RTL8139_INT_RXOVW      0x10

#define RTL8139_RX_BUFFER_SIZE 8192
#define RTL8139_TX_BUFFER_SIZE 2048

int rtl8139_init(void);
int rtl8139_send_packet(const void* data, uint32_t len);
void rtl8139_get_mac_address(uint8_t* mac);
void rtl8139_handle_interrupt(void);
uint32_t rtl8139_get_io_base(void);

#endif
