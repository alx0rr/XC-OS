#include "../include/graphics/vbe.h"

vbe_info_t get_vbe_struct() {
    vbe_info_t vbe = {0};
    return vbe;
}

uint16_t vbe_get_width() {
    return 0;
}

uint16_t vbe_get_height() {
    return 0;
}

uint8_t* vbe_get_framebuffer() {
    return (uint8_t*)0;
}
